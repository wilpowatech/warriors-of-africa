extends Node3D

func _ready():
    create_environment()
    create_ground()
    create_trees()
    create_player()

func create_environment():
    var world = WorldEnvironment.new()
    var environment = Environment.new()
    environment.background_mode = Environment.BG_COLOR
    environment.background_color = Color(0.48, 0.68, 0.82)
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.8, 0.8, 0.75)
    environment.ambient_light_energy = 0.7
    world.environment = environment
    add_child(world)

    var sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50, -30, 0)
    sun.light_energy = 1.2
    sun.shadow_enabled = true
    add_child(sun)

func create_ground():
    var ground = StaticBody3D.new()
    ground.position.y = -0.2

    var mesh = MeshInstance3D.new()
    var plane = PlaneMesh.new()
    plane.size = Vector2(80, 80)
    mesh.mesh = plane

    var material = StandardMaterial3D.new()
    material.albedo_color = Color(0.35, 0.29, 0.17)
    mesh.material_override = material
    ground.add_child(mesh)

    var collision = CollisionShape3D.new()
    var shape = BoxShape3D.new()
    shape.size = Vector3(80, 0.4, 80)
    collision.shape = shape
    ground.add_child(collision)

    add_child(ground)

func create_trees():
    for i in range(12):
        var x = float((i % 4) * 12 - 18)
        var z = float((i / 4) * 12 - 12)

        var tree = Node3D.new()
        tree.position = Vector3(x, 0, z)

        var trunk = MeshInstance3D.new()
        var trunk_mesh = CylinderMesh.new()
        trunk_mesh.top_radius = 0.35
        trunk_mesh.bottom_radius = 0.55
        trunk_mesh.height = 3.5
        trunk.mesh = trunk_mesh

        var trunk_mat = StandardMaterial3D.new()
        trunk_mat.albedo_color = Color(0.28, 0.16, 0.08)
        trunk.material_override = trunk_mat
        trunk.position.y = 1.75
        tree.add_child(trunk)

        var leaves = MeshInstance3D.new()
        var leaves_mesh = SphereMesh.new()
        leaves_mesh.radius = 2.0
        leaves_mesh.height = 3.5
        leaves.mesh = leaves_mesh

        var leaves_mat = StandardMaterial3D.new()
        leaves_mat.albedo_color = Color(0.12, 0.28, 0.09)
        leaves.material_override = leaves_mat
        leaves.position.y = 4.0
        tree.add_child(leaves)

        add_child(tree)

func create_player():
    var player = CharacterBody3D.new()
    player.name = "AfricanWarrior"
    player.position = Vector3(0, 0.1, 4)
    player.set_script(load("res://scripts/player.gd"))
    add_child(player)
